package training;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Cookie;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.io.FileHandler;
import org.openqa.selenium.support.pagefactory.ByAll;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class SeleniumSession7 {
	
	//static WebDriver driver;
	
	public static void captureScreenshot(WebDriver driver, String path) throws IOException
	{
		TakesScreenshot screenshot = ((TakesScreenshot)driver);
		File srcFile = screenshot.getScreenshotAs(OutputType.FILE);
		File destFile = new File(path);
		FileHandler.copy(srcFile, destFile);
	}

	public static void main(String[] args) throws Exception {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Haradhan Pal\\Desktop\\chromedriver.exe"); 
		WebDriver driver = new ChromeDriver();
		/*ChromeOptions option = new ChromeOptions();
		option.setHeadless(true);
		WebDriver driver = new ChromeDriver(option);*/
		driver.manage().window().maximize();
		//WebDriver driver = new HtmlUnitDriver();
		driver.manage().deleteAllCookies();
		driver.get("https://www.google.com/");
		driver.findElement(By.name("q")).sendKeys("selenium");
		
		List <WebElement> options = driver.findElements(By.xpath("//div[@class = 'pcTkSc']"));
		
		System.out.println(options.size());  //11
		for (int i = 0; i<options.size(); i++)
		{
			if(options.get(i).getText().equalsIgnoreCase("selenium tutorial"))
			{
				options.get(i).click();
				break;
			}
		}
		
		/*WebElement email = driver.findElement(new ByAll(By.id("email1"), By.name("email2"), By.xpath("//input[@name = 'email1']")));
		email.sendKeys("User123");*/
		
		
		/*Cookie cookie1 = new Cookie("Google", "www.google.com");
		driver.manage().addCookie(cookie1);
		Cookie cookie2 = new Cookie("Facebook", "www.facebook.com");
		driver.manage().addCookie(cookie2);
		System.out.println(driver.manage().getCookieNamed("Google").getValue());
		System.out.println(driver.manage().getCookieNamed("Google").getName());
		
		Set <Cookie> cookies = driver.manage().getCookies();
		for (Cookie cookie3: cookies)
		{
			System.out.println(cookie3.getName());
			System.out.println(cookie3.getValue());

		}*/

		/*System.out.println(driver.getTitle());
		System.out.println(driver.getCurrentUrl());*/
		
		
		/*System.setProperty("webdriver.chrome.driver", "C:\\Users\\Haradhan Pal\\Desktop\\chromedriver.exe"); 
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		//driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.get("https://www.google.com/");
	
		WebDriverWait wait = new WebDriverWait(driver, 30);
		WebElement gmaillink = wait.until(ExpectedConditions.elementToBeClickable(By.linkText("Gmail")));
		gmaillink.click();*/
		
		/*driver.get("https://jqueryui.com/droppable/");
		SeleniumSession7.captureScreenshot(driver, "D:/Selenium/" + System.currentTimeMillis() + ".png");
		JavascriptExecutor js = (JavascriptExecutor)driver;
		js.executeScript("window.scrollBy(0, 200)");  //scroll vertically down by 200 pixel
		SeleniumSession7.captureScreenshot(driver, "D:/Selenium/" + System.currentTimeMillis() + ".png");
		//driver.switchTo().frame(0);
		driver.switchTo().frame(driver.findElement(By.className("demo-frame")));

		WebElement source = driver.findElement(By.id("draggable"));
		WebElement target = driver.findElement(By.id("droppable"));
		Actions act = new Actions(driver);
		act.dragAndDrop(source, target).build().perform();
		SeleniumSession7.captureScreenshot(driver, "D:/Selenium/" + System.currentTimeMillis() + ".png");
		*//*TakesScreenshot screenshot = ((TakesScreenshot)driver);
		File srcFile = screenshot.getScreenshotAs(OutputType.FILE);
		File destFile = new File("D:/Selenium/Test.png");
		FileHandler.copy(srcFile, destFile);*/

		
		
		/*int framezize = driver.findElements(By.tagName("iframe")).size();
		System.out.println(framezize);*/
		
		
	}

}
