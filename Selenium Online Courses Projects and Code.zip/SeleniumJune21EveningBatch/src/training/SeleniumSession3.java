package training;

class Employee
{
	int empid;
	String companyname;
}

public class SeleniumSession3 {
	
	int i = 100;  //instance variable
	static int  j = 200; //static variable
	
	public void test()
	{
		int a = 10; //local variable
		System.out.println(a);
		
	}

	public static void main(String[] args) {
		
		for(int i = 0; i<10; i++)
		{
			if(i==6)
			{
				continue;
			}
			System.out.println(i);
		}
		
		/*int b = 5;
		do
		{
			System.out.println(b);
			b++;
		}while(b<=4);*/
		
		/*int a = 100;
		while (a>=101)
		{
			System.out.println(a);
			a--;
		}*/
		
		
		/*for(int i = 20; i>10; i--)
		{
			if(i!=15 && i!=17)
			{
			System.out.println(i);
			}
		}*/
		
		/*for(int i = 0; i<10; i++)
		{
			System.out.println(i);
		}*/
		/*int [][] arrInt = {{1,2,3,4}, {5,6,7,8}, {1,9,7,8}};  //row 3 col 4
		
		System.out.println(arrInt[0][1]);  //2
		System.out.println(arrInt[0][2] * arrInt[1][3]);  //3*8
*/
		
				
		/*String arrStr[];
		arrStr = new String[3];  //position  n-1
		arrStr[0] = "Rahul";
		arrStr[1] = "Rajib";
		arrStr[2] = "Sanjib";


		System.out.println(arrStr[0]);
		System.out.println(arrStr[1]);
		System.out.println(arrStr[2] + arrStr[1]);  //null  Sanjib
*/
		
		/*String str1 = "Java String Training";
		String str2 = new String ("Java string");
		
		char [] ch1 = {'h','a','r','a','d','h','a','n'};
		String str3 = new String (ch1);
		//String str4 = null;
		
		System.out.println(str1.substring(5));*/
	//	System.out.println(str1.isEmpty());
		//System.out.println(str4.isEmpty());

		/*System.out.println(str1.startsWith("Java"));
		System.out.println(str1.startsWith("Java1"));
		System.out.println(str1.endsWith("Training"));
		System.out.println(str1.endsWith("Training1"));*/


	/*	System.out.println(str1.compareToIgnoreCase(str2));
		System.out.println(str1.length());
	//	System.out.println(str4.length());
		System.out.println(str1.replace("a", "b"));
		System.out.println(str1.toLowerCase());
		System.out.println(str1.toUpperCase());*/
		/*System.out.println(str1);
		System.out.println(str1.trim());
		System.out.println(str1.contains("Java"));
		System.out.println(str1.contains("Java1"));*/








		
		//System.out.println(str1 + " " +str2+ " "+100);
		/*System.out.println(str1);
		System.out.println(str2);
		System.out.println(str3);*/


	/*	boolean b1 = true;
		boolean b2 = false;
		System.out.println(b1&&b2);
		System.out.println(b1||b2);
		System.out.println(!b2);*/
		
		/*int i = 20;
		int j = 15;
		
		i+= 8;
		j*= 6;
		
		System.out.println(i); //28
		System.out.println(j);  //9
*/
		/*System.out.println(i>j);
		System.out.println(i<j);
		System.out.println(i==j);
		System.out.println(i!=j);*/
		
		/*System.out.println(i+j);
		System.out.println(i-j);
		System.out.println(i*j);
		System.out.println(i/j);
		System.out.println(i%j);*/

	/*	Employee emp1 = new Employee();
		emp1.empid = 100;
		emp1.companyname = "ABCDEF";
		System.out.println(emp1.empid);  //default value of data type
		System.out.println(emp1.companyname);
		Employee emp2 = new Employee();
		emp2.empid = 150;
		emp2.companyname = "ABCDEFGH";
		System.out.println(emp2.empid);  //default value of data type
		System.out.println(emp2.companyname);*/
		
		/*SeleniumSession3 obj = new SeleniumSession3();
			
		System.out.println(j);
		System.out.println(obj.i);
		obj.test();*/

		
		/*int i;
		int i1;

		i = 100;
		i = 200;
		i = 300;
		i = 400;
		System.out.println(i);*/
		
		/*char c = 'A';
		System.out.println(c);
		
		String str = "String Data Type";
		System.out.println(str);*/
		
		/*boolean b1 = true;
		System.out.println(b1);*/
		
		/*double d = 378.8494;
		System.out.println(d);*/
		
		/*int i;
		i = 100;
		i = 200;
		i = 300;
		i = 400;
		System.out.println(i);  //400
*/		
		/*int b = 300;  //-256 to 255
		System.out.println(b);*/
		
		/*System.out.println("Java Program"); //java comments
		System.out.println("Java Program1");
		
		System.out.print("Java Program");
		System.out.print("Java Program1");*/

	}

}
