package training;

public class SeleniumSession5ClassE extends SeleniumSessionClassD{
	
	void test2() {
		System.out.println("Abstract method test2");		
			}

			void test3() {
				System.out.println("Abstract method test3");		
				
			}

	public static void main(String[] args) {
		SeleniumSession5ClassE obje = new SeleniumSession5ClassE();
		obje.test1();
		obje.test2();
		obje.test3();


	}

	

}
