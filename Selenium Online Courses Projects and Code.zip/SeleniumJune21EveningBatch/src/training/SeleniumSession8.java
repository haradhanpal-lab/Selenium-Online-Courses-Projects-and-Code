package training;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.Assertion;
import org.testng.asserts.SoftAssert;

public class SeleniumSession8 {
	
	WebDriver driver;
	
/*@BeforeSuite
public void bsuite() {
	  
	  System.out.println("Output for before suite annotation");
}
@AfterSuite
public void asuite() {
	  
	  System.out.println("Output for after suite annotation");
}
@BeforeClass
public void bclass() {
	  
	  System.out.println("Output for before Class annotation");
}
@AfterClass
public void aclass() {
	  
	  System.out.println("Output for after Class annotation");
}
@BeforeTest
public void btest() {
	  
	  System.out.println("Output for before Test annotation");
}
@AfterTest
public void atest() {
	  
	  System.out.println("Output for after Test annotation");
}
@BeforeMethod
public void bmethod() {
	  
	  System.out.println("Output for before Method annotation");
}
@AfterMethod
public void amethod() {
	  
	  System.out.println("Output for after Method annotation");
}
  @Test
  public void test1() {
	  
	  System.out.println("My first TestNG Class");
  }
  @Test
  public void test2() {
	  
	  System.out.println("My second TestNG Class");
  }*/
	
	@BeforeMethod
	public void setUp() {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Haradhan Pal\\Desktop\\chromedriver.exe"); 
		driver = new ChromeDriver();
		driver.manage().window().maximize();
	}
	@AfterMethod
	public void tearDown() {
		driver.close();

	}
	
 // @Test (invocationCount = 3, skipFailedInvocations = true, invocationTimeOut = 70000)
	@Test
	public void facebook() {
	  System.out.println("Code before assertion added");
	  	driver.get("https://www.facebook.com/");
		System.out.println(driver.getCurrentUrl());
		//Assert.assertEquals(10, 10);
		SoftAssert sa = new SoftAssert();
		sa.assertEquals("TestNG", "TestNG");
		  System.out.println("Code after assertion added");
		  sa.assertAll();

  }
 //@Test(dependsOnMethods = {"facebook"}, alwaysRun = true)
  
  @Test
  public void google() {
	   	driver.get("https://www.google.com/");
		System.out.println(driver.getCurrentUrl());
  }
 
}
