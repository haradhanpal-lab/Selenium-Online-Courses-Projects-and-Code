package test;

public class TestClass {
	
	protected int j = 20;

	public static void main(String[] args) {

	}

}
