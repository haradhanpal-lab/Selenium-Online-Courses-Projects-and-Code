package training;

public class SeleniumSession5Retail implements SeleniumSession5IT{

	public static void main(String[] args) {
		
		SeleniumSession5Retail objretail = new SeleniumSession5Retail();
		objretail.programminglanguage();
		objretail.desktop();
		objretail.laptop();
		objretail.ba();
		objretail.manager();

	}

	public void desktop() {
		System.out.println("30 desktop required");		
			}
	public void laptop() {
		System.out.println("20 laptop required");		
			}
	
	@Override
	public void testing() {
System.out.println("Functional and automation tester required");		
	}

	@Override
	public void development() {
		System.out.println("Java and Python developer required");		
		
	}

	@Override
	public void domain() {
		System.out.println("Retail domain skill required");		
		
	}

	@Override
	public void manager() {
		System.out.println("Dev and QA Manager required");		
		
	}

	@Override
	public void ba() {
		System.out.println("Retail domain skillset required");		
		
	}

	@Override
	public void programminglanguage() {
		System.out.println("Java and Python languages will be used");		
		
	}

	@Override
	public void resources() {
		System.out.println("Total 50 Dev and QA resources required");		
		
	}

}
