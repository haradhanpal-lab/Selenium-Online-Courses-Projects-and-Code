package training;

public class SeleniumSession5 {
	
	int a = 20;  //class variable
	static int b = 30;  //static variable
	
	public void m1()
	{
		System.out.println("Output for Method m1");
	}
	
	public static void m2()
	{
		System.out.println("Output for Method m2");
	}

	public static void main(String[] args) {
		
		System.out.println("Code before Exception");
		try {
			int a = 20/0;
		} catch (Exception e) {
System.out.println(e);	
}
		finally
		{
			System.out.println("Finally block will be executed always");
		}
		System.out.println("Code before Exception");

		
		/*final int a = 50;
		
		
		System.out.println(a);*/
		
		/*SeleniumSession5 obj = new SeleniumSession5();
		System.out.println(b);
		System.out.println(obj.a);
		m2();
		obj.m1();*/

	}

}
