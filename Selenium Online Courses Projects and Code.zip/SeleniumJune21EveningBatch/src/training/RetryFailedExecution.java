package training;

import org.testng.IRetryAnalyzer;
import org.testng.ITestResult;

public class RetryFailedExecution implements IRetryAnalyzer{
	
	int currentTry = 1;
	int maxRetry = 10;

	@Override
	public boolean retry(ITestResult result) {
		if(currentTry < maxRetry)
		{
				currentTry++;
			return true;
		}
		return false;
	}
}
