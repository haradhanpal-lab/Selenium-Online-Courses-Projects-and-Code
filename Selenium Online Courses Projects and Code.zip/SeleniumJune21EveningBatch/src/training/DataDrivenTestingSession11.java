package training;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class DataDrivenTestingSession11 {
	
WebDriver driver;
	
	@BeforeTest
	public void setUp() {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Haradhan Pal\\Desktop\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
	}
	@AfterTest
	public void tearDown() {
		driver.quit();
	}
	
	@Test (dataProvider = "getUserNameandPassord")
	public void facebook(String uname, String password) {
		driver.get("https://mail.rediff.com/cgi-bin/login.cgi");
		driver.findElement(By.id("login1")).sendKeys(uname);
		driver.findElement(By.id("password")).sendKeys(password);
		System.out.println(uname +" "+ password);
		}
	
	@DataProvider
	public Object [][] getUserNameandPassord() throws Exception
	{
		ReadExcelData config = new ReadExcelData("D:\\FacebookLoginCredential.xlsx");
		int rows = config.getRowCount(0);
		Object [][] data = new Object [rows] [2];
		for (int i=0; i<rows; i++)
		{
			data[i][0] = config.getData(0, i, 0);
			data[i][1] = config.getData(0, i, 1);
		}
				
		return data;
	}

}
