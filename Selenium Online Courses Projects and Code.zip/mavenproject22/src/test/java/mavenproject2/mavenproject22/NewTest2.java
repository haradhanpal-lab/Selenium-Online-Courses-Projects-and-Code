package mavenproject2.mavenproject22;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

public class NewTest2 {
	
	
		@Test
	  public void test() {
			  
		System.out.println("Test Method");
	   
	}
}
