package training;

import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

public class TestListeners implements ITestListener{

	@Override
	public void onTestStart(ITestResult result) {
System.out.println("TestNG Method Started: " +result.getName());		
	}

	@Override
	public void onTestSuccess(ITestResult result) {
		System.out.println("TestNG Method Passed: " +result.getName());		
		
	}

	@Override
	public void onTestFailure(ITestResult result) {
		System.out.println("TestNG Method Failed: " +result.getName());				
	}

	@Override
	public void onTestSkipped(ITestResult result) {
		System.out.println("TestNG Method Skipped: " +result.getName());				
	}

	@Override
	public void onTestFailedButWithinSuccessPercentage(ITestResult result) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onStart(ITestContext context) {
		System.out.println("TestNG Class Started: " +context.getName());				
	}

	@Override
	public void onFinish(ITestContext context) {
		System.out.println("TestNG Class Finished: " +context.getName());			
	}

}
