package training;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

//@Listeners(training.TestListeners.class)
public class SeleniumSession9 {
	
	@Test (retryAnalyzer = RetryFailedExecution.class)
	  public void test() {
		  
		  System.out.println("My First TESTNG Project");
	  }
	@Test (retryAnalyzer = RetryFailedExecution.class)
	  public void test1() {
		  
		  System.out.println("My Second TESTNG Project");
		  Assert.assertEquals(20, 21);
	  }
	  @Test
	  public void test2() {
		  
		  System.out.println("My Third TESTNG Project");
	  }
	
	
/*WebDriver driver;
	
	@BeforeTest
	public void setUp() {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Haradhan Pal\\Desktop\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
	}
	@AfterTest
	public void tearDown() {
		driver.quit();
	}
	
	@Test (dataProvider = "getUserNameandPassord")
	public void facebook(String uname, String password) {
		driver.get("https://www.facebook.com/");
		driver.findElement(By.id("email")).sendKeys(uname);
		driver.findElement(By.id("pass")).sendKeys(password);
		System.out.println(uname +" "+ password);
		}
	
	@DataProvider
	public Object [][] getUserNameandPassord()
	{
		Object [][] data = new Object [4][2];
		//Row 1
		data [0][0] = "User111";
		data [0][1] = "Password111";
		//Row 2
		data [1][0] = "User222";
		data [1][1] = "Password222";
		//Row 3
		data [2][0] = "User333";
		data [2][1] = "Password333";
		//Row 4
				data [3][0] = "User444";
				data [3][1] = "Password444";
		
		return data;
	}*/
	/*
	@Parameters ({"Data1", "Data2"})
	@Test
	public void addition(int a, int b)
	{
		int c = a+b;
		System.out.println("Sum of two valiables will be: " +c);
	}
	@Parameters ({"Data1", "Data2", "Data3"})
	@Test
	public void addition3(int a, int b, int d)
	{
		int c = a+b+d;
		System.out.println("Sum of three valiables will be: " +c);
	}
	*/
	/*@Parameters ({"Data1", "Data2"})
	@Test
	public void substraction(int a, int b)
	{
		int c = a-b;
		System.out.println("Substraction of two valiables will be: " +c);
	}*/
	
	/*@Test (groups = {"Appllication1", "SystemTest"})
	  public void testmethod1() {
		  System.out.println("TestNG Method1");
	  }
	  @Test (groups = {"Appllication2", "SanityTest"})
	  public void testmethod2() {
		  System.out.println("TestNG Method2");
	  }
	  @Test (groups = {"SystemTest", "Appllication3", "IntegrationTest"})
	  public void testmethod3() {
		  System.out.println("TestNG Method3");
	  }
	  @Test (groups = {"UATTest", "SanityTest"})
	  public void testmethod4() {
		  System.out.println("TestNG Method4");
	  }
	  @Test (groups = {"Appllication3", "UATTest", "Appllication2"})
	  public void testmethod5() {
		  System.out.println("TestNG Method5");
	  }*/
	  
}

	/*@Test
	  public void enterUserandPassword() {
		  
		  System.setProperty("webdriver.chrome.driver","C:\\Users\\Haradhan Pal\\Desktop\\chromedriver.exe");
	  	  WebDriver driver = new ChromeDriver();
	  	  driver.manage().window().maximize();
	  	  driver.get("https://www.facebook.com/");
	      driver.findElement(By.name("email")).sendKeys("Username123");
	      driver.findElement(By.name("pass")).sendKeys("pass123");
	      System.out.println("User name and password entered in facebook page");
	  	  System.out.println(driver.getTitle());
	      driver.quit();
	  }
	  @Test
	  public void openFacebookPage() {
		  
		  System.setProperty("webdriver.chrome.driver","C:\\Users\\Haradhan Pal\\Desktop\\chromedriver.exe");
	  	  WebDriver driver = new ChromeDriver();
	  	  driver.manage().window().maximize();
	  	  driver.get("https://www.facebook.com/");
	      System.out.println("Facebook page opened successfully");
	  	  System.out.println(driver.getTitle());
	      driver.quit();
	  }
	  @Test
	  public void openGooglePage() {
		  
		  System.setProperty("webdriver.gecko.driver","C:\\Users\\Haradhan Pal\\Desktop\\geckodriver.exe");
		  WebDriver driver2 = new FirefoxDriver();
	  	  driver2.manage().window().maximize();
	  	  driver2.get("http://www.google.com/");
	  	  System.out.println("Google Page open successfully");
	  	  System.out.println(driver2.getTitle());
	      driver2.quit();
	  }
	  
	  @Test
	  public void OpenRediffPage() {
		  
		  System.setProperty("webdriver.chrome.driver","C:\\Users\\Haradhan Pal\\Desktop\\chromedriver.exe");
	  	  WebDriver driver3 = new ChromeDriver();
	  	  driver3.manage().window().maximize();
	  	  driver3.get("https://www.rediff.com/");
	      System.out.println(driver3.getTitle());
	      driver3.quit();
	  }
}*/
	
	/*@Test (retryAnalyzer = RetryFailedExecution.class)
	public void test() {
		  
		  System.out.println("My First TESTNG Project");
		  Assert.assertEquals(10, 10);
	  }
	@Test (retryAnalyzer = RetryFailedExecution.class)
	  public void test1() {
		  
		  System.out.println("My Second TESTNG Project");

	  }
	@Test (retryAnalyzer = RetryFailedExecution.class)
	  public void test2() {
		  
		  System.out.println("My Third TESTNG Project");

	  }*/
	
/*WebDriver driver;
	
	@BeforeTest
	public void setUp() {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Haradhan Pal\\Desktop\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
	}
	@AfterTest
	public void tearDown() {
		driver.quit();
	}
	
	@Test (dataProvider = "getUserNameandPassord")
	public void facebook(String uname, String password) {
		driver.get("https://www.facebook.com/");
		driver.findElement(By.id("email")).sendKeys(uname);
		driver.findElement(By.id("pass")).sendKeys(password);
		System.out.println(uname +" "+ password);
		driver.findElement(By.id("email")).sendKeys("User123");
		driver.findElement(By.id("pass")).sendKeys("Pass123");

	}
	
	@DataProvider
	public Object [][] getUserNameandPassord()
	{
		Object [][] data = new Object [4][2];
		//Row 1
		data [0][0] = "User111";
		data [0][1] = "Password111";
		//Row 2
		data [1][0] = "User222";
		data [1][1] = "Password222";
		//Row 3
		data [2][0] = "User333";
		data [2][1] = "Password333";
		//Row 4
				data [3][0] = "User444";
				data [3][1] = "Password444";
		
		return data;
	}*/
	
	/*@Test
	  public void test() {
		  
		  System.out.println("My First TESTNG Project");
	  }
	  @Test
	  public void test1() {
		  
		  System.out.println("My Second TESTNG Project");
		  Assert.assertEquals(20, 20);
	  }
	  @Test
	  public void test2() {
		  
		  System.out.println("My Third TESTNG Project");
	  }*/
	
	/*@Parameters ({"Data1", "Data2"})
	@Test
	public void addition(int a, int b)
	{
		int c = a+b;
		System.out.println("Sum of two valiables will be: " +c);
	}
	@Parameters ({"Data1", "Data2", "Data3"})
	@Test
	public void addition3(int a, int b, int d)
	{
		int c = a+b+d;
		System.out.println("Sum of three valiables will be: " +c);
	}
	
	@Parameters ({"Data1", "Data2"})
	@Test
	public void substraction(int a, int b)
	{
		int c = a-b;
		System.out.println("Substraction of two valiables will be: " +c);
	}*/
	
	
	/*@Test (groups = {"Appllication1", "SystemTest"})
	  public void testmethod1() {
		  System.out.println("TestNG Method1");
	  }
	  @Test (groups = {"Appllication2", "SanityTest"})
	  public void testmethod2() {
		  System.out.println("TestNG Method2");
	  }
	  @Test (groups = {"SystemTest", "Appllication3", "IntegrationTest"})
	  public void testmethod3() {
		  System.out.println("TestNG Method3");
	  }
	  @Test (groups = {"UATTest", "SanityTest"})
	  public void testmethod4() {
		  System.out.println("TestNG Method4");
	  }
	  @Test (groups = {"Appllication3", "UATTest", "Appllication2"})
	  public void testmethod5() {
		  System.out.println("TestNG Method5");
	  }*/

