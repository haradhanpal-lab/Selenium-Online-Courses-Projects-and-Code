package training;

public class SeleniumSession5ClassB extends SeleniumSession5ClassA{
	int i3= 60;
	public void mul(int a2, int b2)
	{
		int c2 = a2*b2;
		System.out.println(c2);
	}
	public void add(int a, int b)
	{
		int c = a-b;  //substraction
		System.out.println(c);
	}
	String name = "ClassB";
	public void printname()
	{
		System.out.println(name);
		System.out.println(super.name);
	}

	public static void main(String[] args) {
		SeleniumSession5ClassB objb = new SeleniumSession5ClassB();
		objb.printname();
		//objb.add(20, 7);  //13
		/*objb.mul(20, 8);
		System.out.println(objb.i3);
		objb.add(34, 70);
		objb.sub(20, 5.50);
		System.out.println(objb.i1);
		System.out.println(objb.i2);
		*/


	}

}
