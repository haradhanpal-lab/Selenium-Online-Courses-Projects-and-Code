package test;

import org.testng.annotations.Test;

public class Session8 {
  @Test
  public void test1() {
	  System.out.println("Method test1 and package test");
  }
  @Test
  public void test2() {
	  System.out.println("Method test2 and package test");
  }
}
