package training;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class SeleniumSession12ReadWriteData {
WebDriver driver;
XSSFWorkbook workbook;
XSSFSheet worksheet;
XSSFCell cell;
		
	@BeforeTest
	public void setUp() {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Haradhan Pal\\Desktop\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
	}
	@AfterTest
	public void tearDown() {
		driver.quit();
	}
	
	@Test
	 public void facebookLoginPage() throws IOException
	 {
		driver.get("https://www.facebook.com/");
		File file = new File("D:\\FacebookLoginCredential.xlsx");
		//Loading the file
		FileInputStream fis = new FileInputStream(file);
		//Loading the workbook
		workbook = new XSSFWorkbook(fis);
		//Loading the sheet in which data is stored
		worksheet = workbook.getSheetAt(0);
		int rowcount = worksheet.getLastRowNum();
		for(int i=1; i<=rowcount; i++)
		{
			//Import data for email field
			cell = worksheet.getRow(i).getCell(0);
			cell.setCellType(CellType.STRING);
			WebElement email = driver.findElement(By.id("email"));
			email.clear();
			email.sendKeys(cell.getStringCellValue());
			
			//Import data for password field
			cell = worksheet.getRow(i).getCell(0);
			cell.setCellType(CellType.STRING);
			WebElement password = driver.findElement(By.id("pass"));
			password.clear();
			password.sendKeys(cell.getStringCellValue());
			
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			
			FileOutputStream fos = new FileOutputStream (file);
			String testresult = "Test Case Passed";
			//Creating a cell where i need to update test result data
			worksheet.getRow(i).createCell(2).setCellValue(testresult);
			//test result data need to be written after successful run of the test script
			workbook.write(fos);
		}
		
	 }
}
