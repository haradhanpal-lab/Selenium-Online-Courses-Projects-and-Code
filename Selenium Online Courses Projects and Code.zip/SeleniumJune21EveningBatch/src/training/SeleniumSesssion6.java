package training;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.TreeSet;

public class SeleniumSesssion6 implements Runnable{
	
	public void run()
	{
		if(Thread.currentThread().isDaemon())
		{
			System.out.println("It is Daemon Thread");
		}
		else
		{
			System.out.println("It is not Daemon but normal Thread");
		}
		/*for(int i = 0; i<10; i++)
		{
			System.out.println("Thread Value: " +i);
		}*/
	}
	
	public static void main(String[] args) throws Exception {
		
		SeleniumSesssion6 m1 = new SeleniumSesssion6();
		Thread t1 = new Thread(m1);
		t1.setDaemon(true);

		t1.start();
		
		
		SeleniumSesssion6 m2 = new SeleniumSesssion6();
		Thread t2 = new Thread(m2);
		t2.start();

	/*	Thread ct = Thread.currentThread();
		System.out.println(ct.getId());
		System.out.println(ct.getName());
		System.out.println(ct.getPriority());
		System.out.println(ct.getState());
		
		ct.setName("testthread");
		ct.setPriority(2);
		System.out.println(ct.getName());
		System.out.println(ct.getPriority());*/
		
	/*	HashMap <Integer, String> hm = new HashMap <Integer, String> ();
		hm.put(100, "Rahul");
		hm.put(101, "Rahul");
		hm.put(105, "Vijay");
		hm.put(103, "Raghab");
		hm.put(100, "Saroj");
		
		//Print keys
		for(int keys: hm.keySet())
		{
			System.out.println(keys);
		}
		
		//Print Values
				for(int keys: hm.keySet())
				{
					System.out.println(hm.get(keys));
				}
				
				//Print keys Values
						for(int keys: hm.keySet())
						{
							System.out.println(keys + "  " +hm.get(keys));
						}

						System.out.println("----------------");

						hm.remove(101);
						hm.put(110, "Punit");
						hm.replace(103, "Haradhan");
						
						for(int keys: hm.keySet())
						{
							System.out.println(keys + "  " +hm.get(keys));
						}
		*/
		/*TreeSet <String> ts = new TreeSet <String>();
		ts.add("UFT");
		ts.add("UFT");
		ts.add("Selenium");
		ts.add("Tosca");
		ts.add("RFT");
		ts.add("RFT");
		ts.add("TestNG");
		ts.add("Apium");

		
		for(String ts1 : ts)
			System.out.println(ts1); */
		
		/*ArrayList <Integer> ar = new ArrayList <Integer> ();
		ar.add(20);
		ar.add(30);
		ar.add(20);
		ar.add(50);
		ar.add(25);
				for(int ar1 : ar)
			System.out.println(ar1);  
				System.out.println("----------------");
				
				HashSet <Integer> hs = new HashSet <Integer>(ar);
				for(int hs1 : hs)
					System.out.println(hs1);  
				
				System.out.println("----------------");
				HashSet <Integer> hs2 = new HashSet <Integer>();
				hs2.add(100);
				hs2.add(200);
				hs2.add(100);
				hs2.addAll(ar);

				for(int hs3 : hs2)
					System.out.println(hs3);  */
				
				
		
		/*HashSet <String> hs = new HashSet <String>();
		hs.add("UFT");
		hs.add("UFT");
		hs.add("Selenium");
		hs.add("Tosca");
		hs.add("RFT");
		hs.add("RFT");
		
		for(String hs1 : hs)
			System.out.println(hs1);  //Enhanced for loop

System.out.println("*****");

hs.add("Maven");
hs.add("Junit");
hs.remove("UFT");

for(String hs1 : hs)
	System.out.println(hs1);  		*/
		
	/*	LinkedList <Integer> ll = new LinkedList <Integer> ();
		System.out.println(ll.isEmpty()); //true
		ll.add(20);
		ll.add(30);
		ll.add(20);
		ll.add(50);
		ll.add(25);
		System.out.println(ll.isEmpty()); //false
		System.out.println(ll.size());
		//Collections.sort(ar);
for (int i = 0; i<ll.size(); i++)
{
	System.out.println(ll.get(i));
}

System.out.println("*****");
ll.removeFirst();
ll.removeLast();
ll.addFirst(100);
ll.addLast(200);

for (int i = 0; i<ll.size(); i++)
{
	System.out.println(ll.get(i));
}*/
		
		
		/*ArrayList <Integer> ar = new ArrayList <Integer> ();
		System.out.println(ar.isEmpty()); //true
		ar.add(20);
		ar.add(30);
		ar.add(20);
		ar.add(50);
		ar.add(25);
		System.out.println(ar.isEmpty()); //false
		//Collections.sort(ar);
for (int i = 0; i<ar.size(); i++)
{
	System.out.println(ar.get(i));
}

System.out.println("*******");

ar.add(200);
ar.remove(0);
ar.set(2, 500);*/

/*
for (int i = 0; i<ar.size(); i++)
{
	System.out.println(ar.get(i));
}
*/

		

		
		
		
	/*	String textcontent;
		File file = new File("D://Selenium//Test1.txt");
		
		FileReader fr = new FileReader(file);
		BufferedReader br = new BufferedReader(fr);
		while((textcontent = br.readLine()) != null)
		{
			System.out.println(textcontent);
		}		
		br.close();
		fr.close();*/
		
		
		/*FileWriter fw = new FileWriter(file);
		BufferedWriter bw = new BufferedWriter(fw);
		bw.write("Selenium with Java Online Training");
		bw.close();
		fw.close();*/
		
		//file.setReadOnly();
		
	/*	System.out.println(file.canRead());
		System.out.println(file.canWrite());  //False
		file.delete();
		*/
		
		/*file.createNewFile();
		System.out.println(file.getName());
		System.out.println(file.getPath());
		System.out.println(file.canRead());
		System.out.println(file.canWrite());
		System.out.println(file.length());
		Boolean b1 = file.exists();
		if(b1==true)
		{
			System.out.println("File created successfully");
		}
		else
		{
			System.out.println("File does not created successfully");
		}*/
		

	/*File folder = new File("D://JavaTraining");
	//folder.mkdir();
	
	Boolean b1 = folder.exists();
	if(b1==true)
	{
		System.out.println("Folder created successfully");
	}
	else
	{
		System.out.println("Folder does not created successfully");
	}
	folder.delete();  //folder will be deleted
	Boolean b2 = folder.exists();
	if(b2==true)
	{
		System.out.println("Folder is present");
	}
	else
	{
		System.out.println("Folder deleted successfully");
	}*/
	
	
	
	
	}

}
