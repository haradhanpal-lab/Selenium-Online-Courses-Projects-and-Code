package StepDefinitions;

import java.io.File;
import java.io.IOException;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class GoogleSearchEngine {
	
	
	/*@Before(order=0)
    public void setUp() {
        System.out.println("This will execute first--Before");
    } 
    @After(order=1)
    public void tearDown() {
        System.out.println("This will execute first--After");
    }    
    @Before(order=1)
    public void setUpTwo() {
        System.out.println("This will execute second--Before");
    }    
    @After(order=0)
    public void afterOne() {
        System.out.println("This will execute second--After");
    }*/
	
	/*@Before ("@Smoke")
	public void setUp()
	{
		System.out.println("The Method will run before every Smoke Test scenario");
	}
	@After ("@Smoke")
	public void tearDown()
	{
		System.out.println("The Method will run after every Smoke Test scenario");
	}
	@Before ("@Integration")
	public void setUpIntegration()
	{
		System.out.println("The Method will run before every Integration Test scenario");
	}
	@After ("@Integration")
	public void tearDownIntegration()
	{
		System.out.println("The Method will run after every Integration Test scenario");
	}*/
	
	/*@Before
	public void setUp()
	{
		System.out.println("The Set Up Method will run before every scenario");
	}
	@After
	public void tearDown()
	{
		System.out.println("The Tear Down Method will run after every scenario");
	}*/
	
	@Given("Google Home Page Open")
	public void google_home_page_open() {
		System.out.println("@Given -- User launch Browser and then open Google Home Page");

	}

	@Given("Search Text Box is visible and Enabled")
	public void search_text_box_is_visible_and_enabled() {
		System.out.println("@Given -- Validate the existance of Serach Text box in Google Home Page");

	}

	@When("User Search a Course with Keyword Cucumber Tutorial")
	public void user_search_a_course_with_keyword_cucumber_tutorial() {
		System.out.println("@When -- User enter Cucumber Tutorial keyword in Google Home Page");

	}

	@When("Hit Enter")
	public void hit_enter() {
		System.out.println("@When -- User Press Enter button from Keyboeard");

	}

	@Then("All Courses related to Cucumber Tutorial should be displayed")
	public void all_courses_related_to_cucumber_tutorial_should_be_displayed() {

		System.out.println("@Then -- User able to search relevant courses for Cucumber Tutorial");

	}

	@When("User Search a Course with Keyword Java Tutorial")
	public void user_search_a_course_with_keyword_java_tutorial() {
		System.out.println("@When -- User enter Java Tutorial keyword in Google Home Page");

	}

	@Then("All Courses related to Java Tutorial should be displayed")
	public void all_courses_related_to_java_tutorial_should_be_displayed() {
		System.out.println("@Then -- User able to search relevant courses for Java Tutorial");

	}

}
