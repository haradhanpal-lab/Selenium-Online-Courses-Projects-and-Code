package training;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class SeleniumSession4 {
	
	public SeleniumSession4()
	{
		System.out.println("default constructor");
	}
	public SeleniumSession4(int a)
	{
		System.out.println("Constructor" + " " + a);
	}
	public SeleniumSession4(double d)
	{
		System.out.println("Constructor" + " " + d);
	}
	
	public void method1()
	{
		System.out.println("hello java");
	}
	 public static int mul(int a, int b)
	{
		int c = a*b;
		return c;
	}
	public int add(int a, int b)
	{
		int c = a+b;
		return c;
	}
	public double sub(double i, double j)
	{
		double k = i-j;
		return k;
	}

	public static void main(String[] args) {
		System.out.println("Sum of int 10 and 5 is 15");
		
		try
		{
		int a[] = new int [5];
		a[3] = 10;
		}
		catch (Exception e)
		{
			System.out.println(e);
		}
		/*try {
			int i = 10/0;
		} catch (ArithmeticException exception1) {
System.out.println(exception1);		
}*/
		System.out.println("Multiplication of int 10 and 5 is 50");
		System.out.println("Substraction of int 10 and 5 is 5");

		
		
		/*Date dt = new Date();
		System.out.println(dt.toString());
		
		String dateformat = "hh:mm:ss a yyyy/MMM/dd";
		SimpleDateFormat sdf = new SimpleDateFormat(dateformat);
		System.out.println(sdf.format(dt));*/
		
	/*	Calendar cal = Calendar.getInstance();
		System.out.println(cal.getTime());
		System.out.println(cal.get(Calendar.YEAR));
		System.out.println(cal.get(Calendar.MONTH));
		System.out.println(cal.get(Calendar.HOUR));
		//System.out.println(cal.get(Calendar.DAY_OF_WEEK));
		cal.set(2020, 8, 20);
		System.out.println(cal.getTime());
		System.out.println(cal.get(Calendar.YEAR));
		System.out.println(cal.get(Calendar.MONTH));
		System.out.println(cal.get(Calendar.HOUR));
		cal.add(Calendar.YEAR, 1);
		cal.add(Calendar.MONTH, 2);
		cal.add(Calendar.HOUR, 5);
		System.out.println(cal.getTime());
		System.out.println(cal.get(Calendar.YEAR));
		System.out.println(cal.get(Calendar.MONTH));
		System.out.println(cal.get(Calendar.HOUR));
		System.out.println(cal.get(Calendar.ZONE_OFFSET));*/


		
		
		
		/*String str = "1200.5677";
		System.out.println(str+100); //1200.5677100
		
		double strtodouble = Double.parseDouble(str);
		System.out.println(strtodouble+100); //1300.5677
*/		
		/*String str = "1200";
		System.out.println(str+100); //1200100
		
		int strtoint = Integer.parseInt(str);
		System.out.println(strtoint+100); //1300
*/
		
	/*	int a = 10;
		System.out.println(a);
		Integer intobj = new Integer(a);
		System.out.println(intobj);
		double d = 1076788.9900;
		System.out.println(d);
		Double doubleobj = new Double(d);
		System.out.println(doubleobj);*/
		
		
	/*	SeleniumSession4 obj1 = new SeleniumSession4();
		SeleniumSession4 obj2 = new SeleniumSession4();
		SeleniumSession4 obj3 = new SeleniumSession4();
		SeleniumSession4 obj4 = new SeleniumSession4(5);
		SeleniumSession4 obj5 = new SeleniumSession4(57993.7783);*/
		
		
	//System.out.println(mul(10,5));
		
		/*SeleniumSession4 obj = new SeleniumSession4();
System.out.println(obj.add(10, 8));	
System.out.println(obj.sub(100.99, 50.49));*/


/*obj.method1();
		obj.method1();
		obj.method1();
		obj.method1();
		obj.method1();*/

		/*System.out.println("hello java1");
		System.out.println("hello java1");
		System.out.println("hello java1");
		System.out.println("hello java1");
		System.out.println("hello java1");*/

		
		/*int rollno = 1;
		
		switch(rollno) 
		{
		case 1:
			System.out.println("Student is the 1st boy/girl in the class");
			break;
		case 2:
			System.out.println("Student is the 2nd boy/girl in the class");
			break;
		case 3:
			System.out.println("Student is the 3rd boy/girl in the class");
			break;
		case 4:
			System.out.println("Student is the 4th boy/girl in the class");
			break;
		case 5:
			System.out.println("Student is the 5th boy/girl in the class");
			break;
		default:
			System.out.println("Student is not belonging to top 5 in the class");
		}*/
		
		/*int mark = 25;
		
		if(mark>= 30 && mark<45)
		{
			System.out.println("Average - Grade D");
		}
		else if(mark>= 45 && mark<60)
		{
			System.out.println("Good - Grade C");
		}
		else if(mark>= 60 && mark<80)
		{
			System.out.println("Very Good - Grade B");
		}
		else if(mark>= 80)
		{
			System.out.println("Excellent - Grade A");
		}
		else
		{
			System.out.println("Failed - No Grade");
		}*/
		
		/*int age = 33;
		
		if(age>=18)
		{
			if(age>=25)
			{
				System.out.println("The person is allowed to cast their vote and contest election");
			}
			else
			{
				System.out.println("The person is allowed to cast their vote but not be able to contest election");
			}
			
		}
		else
		{
			System.out.println("The person is not allowed to cast their vote");
	
		}*/
		
		
		
		/*if(age>=60)
		{
			System.out.println("The person is senior citizen");
		}
		else
		{
			System.out.println("The person is not a senior citizen");
	
		}*/

	}

}
