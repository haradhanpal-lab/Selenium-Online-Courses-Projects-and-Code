package training;

abstract class SeleniumSessionClassD {
	
	public void test1()
	{
		System.out.println("Non Abstract Method for class D");
	}
	abstract void test2();
	abstract void test3();

	public static void main(String[] args) {
		
		

	}

}
