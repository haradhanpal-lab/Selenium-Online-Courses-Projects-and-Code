package training;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class SeleniumSession2 {

	public static void main(String[] args) throws Exception {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Haradhan Pal\\Desktop\\chromedriver.exe"); 
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("http://register.rediff.com/register/register.php?FormName=user_details");
		driver.findElement(By.xpath("//input[starts-with(@name,'name')]")).sendKeys("Haradhan");
		driver.findElement(By.cssSelector("input#mobno")).sendKeys("672992992");
		
		
		//driver.findElement(By.xpath("//a[text() = 'terms and conditions']")).click();
		
		/*JavascriptExecutor jse = (JavascriptExecutor)driver;
		WebElement privacypolicylink = driver.findElement(By.linkText("privacy policy"));
		jse.executeScript("arguments[0].scrollIntoView()", privacypolicylink);
		privacypolicylink.click();*/
		
		
		//jse.executeScript("window.scrollTo(0, document.body.scrollHeight)");
		//jse.executeScript("window.scrollBy(0,50)");  //vertically down by 200 piexels
		
		/*Select countryoption = new Select(driver.findElement(By.id("country")));
		List <WebElement> countries = countryoption.getOptions();
		System.out.println(countries.size());
		for(int i = 0; i<countries.size(); i++)
		{
			System.out.println(countries.get(i).getText());
		}*/
		
		
		/*countryoption.selectByIndex(10);  //australia
		Thread.sleep(3000);
		countryoption.selectByValue("18");  //Barbados
		Thread.sleep(3000);
		countryoption.selectByVisibleText("Cambodia");*/
	
		
		
		
		
		/*driver.get("http://demo.guru99.com/test/radio.html");
		WebElement radiobutton3 = driver.findElement(By.id("vfb-7-3"));
		WebElement radiobutton2 = driver.findElement(By.id("vfb-7-2"));
		System.out.println(radiobutton3.isDisplayed()); //true
		System.out.println(radiobutton3.isEnabled());//true
		System.out.println(radiobutton3.isSelected());//false
		radiobutton3.click();
		System.out.println(radiobutton3.isSelected());//true
		Thread.sleep(3000);
		radiobutton2.click();
		System.out.println(radiobutton3.isSelected());//false
		Thread.sleep(3000);
		driver.close();*/
		/*WebElement checkbox3 = driver.findElement(By.id("vfb-6-2"));
		System.out.println(checkbox3.isDisplayed()); //true
		System.out.println(checkbox3.isEnabled());//true
		System.out.println(checkbox3.isSelected());//false
		checkbox3.click();
		System.out.println(checkbox3.isDisplayed()); //true
		Thread.sleep(3000);
		checkbox3.click();
		System.out.println(checkbox3.isDisplayed()); //false
		Thread.sleep(3000);
		driver.close();*/
		
		/*driver.get("https://www.facebook.com/");
		WebElement facebookimage = driver.findElement(By.xpath("//*[@id=\"content\"]/div/div/div/div[1]/div/img"));
		System.out.println(facebookimage.getAttribute("class"));
		System.out.println(facebookimage.getAttribute("src"));
		System.out.println(facebookimage.getAttribute("alt"));*/

	}

}
