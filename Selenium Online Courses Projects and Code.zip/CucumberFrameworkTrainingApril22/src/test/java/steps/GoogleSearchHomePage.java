package steps;



import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class GoogleSearchHomePage {
	
	/*@Before(order=0)
    public void setUp() {
        System.out.println("This will execute first--Before");
    } 
    @After(order=1)
    public void tearDown() {
        System.out.println("This will execute first--After");
    }    
    @Before(order=1)
    public void setUpTwo() {
        System.out.println("This will execute second--Before");
    }    
    @After(order=0)
    public void afterOne() {
        System.out.println("This will execute second--After");
    }*/
	//WebDriver driver;
	
	/*@Before("@Smoke")
	public void setUpSmoke()
	{
		System.out.println("Starting Smoke Test Scenario");
	}
	@After("@Smoke")
	public void tearDownSmoke()
	{
		System.out.println("Closing Smoke Test Scenario");
	}
	@Before ("@UAT")
	public void setUpUAT()
	{
		System.out.println("Starting UAT Test Scenario");
	}
	@After ("@UAT")
	public void tearDownUAT()
	{
		System.out.println("Closing UAT Test Scenario");
	}
	@Before ("@Negative")
	public void setUpNegative()
	{
		System.out.println("Starting Negative Test Scenario");
	}
	@After ("@Negative")
	public void tearDownNegative()
	{
		System.out.println("Closing Negative Test Scenario");
	}*/
	/*@Before
	public void setUp()
	{
		System.out.println("Starting Test Scenario");
	}
	@After
	public void tearDown()
	{
		System.out.println("Closing Test Scenario");
	}*/

	//googleSearch.feature
	@Given("Google Home Page Open in Chrome Browser")
	public void google_home_page_open_in_chrome_browser() {
		System.out.println("@Given -- User launch Chrome Browser and open Google Page");

	}

	@Given("Search Text Box is available and editable in the Google Home Page")
	public void search_text_box_is_available_and_editable_in_the_google_home_page() {
		System.out.println("@Given -- User verify the existnace of Search text box");

	}

	@When("User search a tutorial with keyword Cucumber Java Tutorial")
	public void user_search_a_tutorial_with_keyword_cucumber_java_tutorial() {
		System.out.println("@When -- User enter Cucumber Java Tutorial in the serch text box");


	}

	@When("User hits Enter button using keyboard")
	public void user_hits_enter_button_using_keyboard() {
		System.out.println("@When -- User press Enter Keyword from keyboard");


	}

	@Then("All Courses related to Cucumber Java Tutorial should be displayed")
	public void all_courses_related_to_cucumber_java_tutorial_should_be_displayed() {
		System.out.println("@Then -- User able to see all the relevant courses for Cucumber Java Tutorial");


	}

	@When("User search a tutorial with keyword Cucumber Selenium Tutorial")
	public void user_search_a_tutorial_with_keyword_cucumber_selenium_tutorial() {

	}

	@Then("All Courses related to Cucumber Selenium Tutorial should be displayed")
	public void all_courses_related_to_cucumber_selenium_tutorial_should_be_displayed() {

	}
	
	//facebookHomePage.feature
	
	@Given("User Navigates to the Facebook Login Home Page")
	public void user_navigates_to_the_facebook_login_home_page() {
		/*System.setProperty("webdriver.chrome.driver", "C:\\Users\\Haradhan Pal\\Desktop\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.facebook.com/");*/
	   
	}

	@When("User enters {string} as user name and {string} as password")
	public void user_enters_as_user_name_and_as_password(String string, String string2) {
	  
	}

	@Then("Login should be {string} for the Facebook Home Page")
	public void login_should_be_for_the_facebook_home_page(String string) {
	  
	}
	
	@When("User enters Username123 as user name and Password123 as password")
	public void user_enters_username123_as_user_name_and_password123_as_password() {
	    
	}

	@Then("Login should be Unsuccessful for the Facebook Home Page")
	public void login_should_be_unsuccessful_for_the_facebook_home_page() {
	    
	}

	@When("User enters Username123 as user name and Password456 as password")
	public void user_enters_username123_as_user_name_and_password456_as_password() {
	    
	}

	@When("User enters Username111 as user name and Password111 as password")
	public void user_enters_username111_as_user_name_and_password111_as_password() {
	    
	}

	@Then("Login should be Successful for the Facebook Home Page")
	public void login_should_be_successful_for_the_facebook_home_page() {
	    
	}

}
