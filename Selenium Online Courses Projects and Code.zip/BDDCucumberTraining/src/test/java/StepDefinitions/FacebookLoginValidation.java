package StepDefinitions;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class FacebookLoginValidation {
	
	@Given("User login to the Facebook Home Page")
	public void user_login_to_the_facebook_home_page() {
	   
	}

	@When("User enter username1 as UserName and password1 as Password")
	public void user_enter_username1_as_user_name_and_password1_as_password() {
	  
	}

	@Then("Login should be Successful for Facebook")
	public void login_should_be_successful_for_facebook() {
	   
	}

	@When("User enter username2 as UserName and password1 as Password")
	public void user_enter_username2_as_user_name_and_password1_as_password() {
	   
	}

	@Then("Login should be Unsuccessful for Facebook")
	public void login_should_be_unsuccessful_for_facebook() {
	   
	}

	@When("User enter username2 as UserName and password2 as Password")
	public void user_enter_username2_as_user_name_and_password2_as_password() {
	    
	}

	@When("User enter username2 as UserName and password3 as Password")
	public void user_enter_username2_as_user_name_and_password3_as_password() {
	    
	}

	@Then("Login should be UnSuccessful for Facebook")
	public void login_should_be_un_successful_for_facebook() {
	    
	}

}
