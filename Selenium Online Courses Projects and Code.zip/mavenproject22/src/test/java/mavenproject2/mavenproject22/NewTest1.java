package mavenproject2.mavenproject22;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class NewTest1 {
	
	WebDriver driver;
	@BeforeTest
	public void setUp() {
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Haradhan Pal\\Desktop\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
	}
	@AfterTest
	public void tearDown() {
		driver.quit();

	}
	
		@Test
	  public void google() {
		driver.get("https://www.google.com/");	  
		System.out.println(driver.getTitle());
	   
	}
		
		@Test
		  public void facebook() {
			driver.get("https://www.facebook.com/");	  
			System.out.println(driver.getTitle());
		   
		}
	
	/*@Test
	  public void facebook() {
			WebDriver driver = new HtmlUnitDriver();
		driver.get("https://www.facebook.com/");	  
		System.out.println(driver.getTitle());
	   
	}*/
	
}
