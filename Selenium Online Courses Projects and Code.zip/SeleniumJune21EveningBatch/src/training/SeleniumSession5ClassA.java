package training;

public class SeleniumSession5ClassA {
	
	/*public SeleniumSession5ClassA()
	{
		System.out.println("Test");
	}*/
	
	int i1 = 20;
	int i2 = 50;
	
	String name = "ClassA";
	public void printname()
	{
		System.out.println(name);
	}
	public void add(int a, int b)
	{
		int c = a+b;  //addition
		System.out.println(c);
	}
	public void add(int a, int b, int c)
	{
		int d = a+b+c;
		System.out.println(d);
	}
	public void add(double a, double b, double c)
	{
		double d = a+b+c;
		System.out.println(d);
	}
	public void add(double a, double b)
	{
		double c = a+b;
		System.out.println(c);
	}
	public void sub(double a1, double b1)
	{
		double c1 = a1-b1;
		System.out.println(c1);
	}

	public static void main(String[] args) {
		SeleniumSession5ClassA obja = new SeleniumSession5ClassA();
		obja.add(45.09, 990.89);
		obja.add(45, 89);
		obja.add(45, 6, 90.990);
		
		/*System.out.println(obja.i1);
		System.out.println(obja.i2);
		obja.sub(100.66, 20.65);
		obja.add(45, 12);*/

		
		
		
	}

}
