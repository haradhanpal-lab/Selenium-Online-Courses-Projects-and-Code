package training;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadExcelData {
	
	XSSFWorkbook wb;
	XSSFSheet sheet;
	
	public ReadExcelData(String excelpath) throws Exception
	{
		File file = new File(excelpath);
		FileInputStream fis = new FileInputStream(file);
		wb= new XSSFWorkbook(fis);
	}
	
	public String getData(int sheetnumber, int row, int column)
	{
		sheet= wb.getSheetAt(sheetnumber);
		String data = sheet.getRow(row).getCell(column).getStringCellValue();
		return data;
	}
	
	public int getRowCount(int sheetnumber)
	{
		int row = wb.getSheetAt(sheetnumber).getLastRowNum();
		row = row+1;
		return row;
	}
	

}
