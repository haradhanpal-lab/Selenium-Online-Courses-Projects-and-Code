package TestRunner;

import org.junit.runner.RunWith;
import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(
	    features = ("src/test/java/Features"),
		glue = ("StepDefinitions"),
	    plugin = {"pretty", "html:test-output", "json:target/cucumber-report/cucumber.json" },
		//plugin = { "pretty", "com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:"},
		//tags = ("@UAT"),
		//plugin = {"pretty", "junit:target/junit-reports/", "junit:target/xml-reports/report.xml", "json:target/json-reports/report.json", "html:target/html-reports/report.html"},
		//plugin = {"pretty", "junit:target/xml-reports/report.xml"},
		//plugin = {"pretty", "json:target/json-reports/report.json"},
		//plugin = {"pretty", "html:target/html-reports/report.html"},
		monochrome = true,
		publish = true
		)

public class Runner {
	
	
}
