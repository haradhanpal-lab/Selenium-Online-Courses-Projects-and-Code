package training;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class SeleniumSession1 {

	public static void main(String[] args) throws Exception {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Haradhan Pal\\Desktop\\chromedriver.exe"); 
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.google.com/");
		
		/*
		List <WebElement> links = driver.findElements(By.tagName("a"));
		System.out.println(links.size());
		for(int i = 0; i<links.size(); i++)
		{
			//System.out.println(links.get(i).getText());
			if(links.get(i).getText().equalsIgnoreCase("gmail"))
			{
				links.get(i).click();
			}
		}
		*/
	/*	WebElement searchtext = driver.findElement(By.name("q"));
		
		System.out.println(searchtext.getAttribute("class"));
		System.out.println(searchtext.getAttribute("name"));*/
		
		
		/*System.out.println(searchtext.isDisplayed()); //true
		System.out.println(searchtext.isEnabled());  //true
		searchtext.sendKeys("Selenium Testing");		
		Thread.sleep(3000);
		searchtext.clear();
		Thread.sleep(3000);

		searchtext.sendKeys("Java");
		Thread.sleep(3000);

		driver.close();*/
		/*WebElement imagelink = driver.findElement(By.linkText("Images"));
		System.out.println(imagelink.isDisplayed());
		System.out.println(imagelink.isEnabled());
		imagelink.click();*/

		/*driver.findElement(By.xpath("//*[@id=\"email\"]")).sendKeys("Username123");
		driver.findElement(By.cssSelector("#pass")).sendKeys("Password123");*/
		
		
		
		
		/*	System.setProperty("webdriver.gecko.driver", "C:\\Users\\Haradhan Pal\\Desktop\\geckodriver.exe");
		WebDriver driver = new FirefoxDriver(); //IEDriver  ie
*/
		/*driver.navigate().to("https://www.facebook.com/");
		driver.navigate().back();
		driver.navigate().forward();
		System.out.println("Google page should open");
		System.out.println(driver.getTitle());
		System.out.println(driver.getCurrentUrl());
		driver.close();*/
		// System.out.println(driver.getPageSource());
	
	}

}
