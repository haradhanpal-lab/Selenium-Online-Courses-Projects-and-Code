package training;

import test.TestClass;

public class SeleniumSession5ClassC extends SeleniumSession5ClassB{

	public static void main(String[] args) {
		SeleniumSession5ClassC objc = new SeleniumSession5ClassC();
		objc.mul(10, 12);
		objc.add(30, 40);
	}

}
