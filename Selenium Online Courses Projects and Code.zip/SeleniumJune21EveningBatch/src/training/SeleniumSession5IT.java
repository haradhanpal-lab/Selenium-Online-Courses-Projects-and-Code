package training;

public interface SeleniumSession5IT {
	
	public void testing();
	public void development();
	public void domain();
	public void manager();
	public void ba();
	public void programminglanguage();
	public void resources();


}
